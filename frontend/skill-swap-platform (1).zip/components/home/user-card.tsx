"use client"

import { useState } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, CheckCircle } from "lucide-react"
import { useAuth } from "@/components/providers/auth-provider"
import { SwapRequestModal } from "@/components/swaps/swap-request-modal"

interface UserCardProps {
  user: {
    id: string
    name: string
    location: string
    profile_photo_url?: string
    skills: Array<{
      id: string
      name: string
      type: "Offered" | "Wanted"
      is_verified: boolean
      verification_count: number
    }>
    average_rating: number
    completed_swaps: number
  }
}

export function UserCard({ user }: UserCardProps) {
  const { user: currentUser } = useAuth()
  const [showSwapModal, setShowSwapModal] = useState(false)

  const offeredSkills = user.skills.filter((skill) => skill.type === "Offered")
  const wantedSkills = user.skills.filter((skill) => skill.type === "Wanted")

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
      />
    ))
  }

  return (
    <>
      <Card className="hover:shadow-lg transition-shadow duration-200 bg-card/50 backdrop-blur border-border/50">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3 mb-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.profile_photo_url || "/placeholder.svg"} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <Link href={`/users/${user.id}`} className="hover:underline">
                <h3 className="font-semibold text-lg truncate">{user.name}</h3>
              </Link>
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="h-3 w-3 mr-1" />
                <span className="truncate">{user.location}</span>
              </div>
            </div>
          </div>

          {/* Rating and Swaps */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-1">
              {renderStars(user.average_rating)}
              <span className="text-sm text-muted-foreground ml-1">({user.average_rating.toFixed(1)})</span>
            </div>
            <span className="text-sm text-muted-foreground">{user.completed_swaps} swaps</span>
          </div>

          {/* Skills Offered */}
          {offeredSkills.length > 0 && (
            <div className="mb-3">
              <h4 className="text-sm font-medium text-primary mb-2">Offers</h4>
              <div className="flex flex-wrap gap-1">
                {offeredSkills.slice(0, 3).map((skill) => (
                  <Badge
                    key={skill.id}
                    variant="secondary"
                    className={`text-xs ${skill.is_verified || skill.verification_count > 0 ? "bg-primary/20 text-primary" : ""}`}
                  >
                    {skill.name}
                    {(skill.is_verified || skill.verification_count > 0) && <CheckCircle className="h-3 w-3 ml-1" />}
                  </Badge>
                ))}
                {offeredSkills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{offeredSkills.length - 3}
                  </Badge>
                )}
              </div>
            </div>
          )}

          {/* Skills Wanted */}
          {wantedSkills.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Wants</h4>
              <div className="flex flex-wrap gap-1">
                {wantedSkills.slice(0, 3).map((skill) => (
                  <Badge key={skill.id} variant="outline" className="text-xs">
                    {skill.name}
                  </Badge>
                ))}
                {wantedSkills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{wantedSkills.length - 3}
                  </Badge>
                )}
              </div>
            </div>
          )}
        </CardContent>

        <CardFooter className="p-4 pt-0">
          {currentUser ? (
            <Button onClick={() => setShowSwapModal(true)} className="w-full" disabled={currentUser.id === user.id}>
              {currentUser.id === user.id ? "Your Profile" : "Request Swap"}
            </Button>
          ) : (
            <Button variant="outline" className="w-full bg-transparent" disabled>
              Login to Request
            </Button>
          )}
        </CardFooter>
      </Card>

      {currentUser && <SwapRequestModal open={showSwapModal} onOpenChange={setShowSwapModal} targetUser={user} />}
    </>
  )
}
