import { Suspense } from "react"
import { Header } from "@/components/layout/header"
import { SearchFilters } from "@/components/home/search-filters"
import { UserDirectory } from "@/components/home/user-directory"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

export default function HomePage() {
  return (
    <div className="min-h-screen gradient-bg">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-green-400 bg-clip-text text-transparent">
            Discover & Exchange Skills
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Connect with talented individuals in your community. Share what you know, learn what you need.
          </p>
        </div>

        <SearchFilters />

        <Suspense fallback={<LoadingSpinner />}>
          <UserDirectory />
        </Suspense>
      </main>
    </div>
  )
}
