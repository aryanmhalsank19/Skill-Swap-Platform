"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/components/providers/auth-provider"
import { UserNav } from "./user-nav"
import { AuthModal } from "@/components/auth/auth-modal"
import { Menu, X } from "lucide-react"

export function Header() {
  const { user, isLoading } = useAuth()
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">S</span>
              </div>
              <span className="font-bold text-xl">Skill Swap</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/browse" className="text-foreground/80 hover:text-foreground transition-colors">
                Browse
              </Link>
              <Link href="/how-it-works" className="text-foreground/80 hover:text-foreground transition-colors">
                How it Works
              </Link>
            </nav>

            {/* Desktop Auth */}
            <div className="hidden md:flex items-center space-x-4">
              {isLoading ? (
                <div className="w-8 h-8 animate-pulse bg-muted rounded-full" />
              ) : user ? (
                <UserNav user={user} />
              ) : (
                <Button onClick={() => setShowAuthModal(true)} className="bg-primary hover:bg-primary/90">
                  Login / Sign Up
                </Button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-border/40">
              <nav className="flex flex-col space-y-4">
                <Link href="/browse" className="text-foreground/80 hover:text-foreground transition-colors">
                  Browse
                </Link>
                <Link href="/how-it-works" className="text-foreground/80 hover:text-foreground transition-colors">
                  How it Works
                </Link>
                {!user && (
                  <Button onClick={() => setShowAuthModal(true)} className="bg-primary hover:bg-primary/90 w-fit">
                    Login / Sign Up
                  </Button>
                )}
              </nav>
            </div>
          )}
        </div>
      </header>

      <AuthModal open={showAuthModal} onOpenChange={setShowAuthModal} />
    </>
  )
}
