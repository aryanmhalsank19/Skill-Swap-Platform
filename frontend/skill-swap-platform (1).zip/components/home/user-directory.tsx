"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { UserCard } from "./user-card"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { BASE_URL } from "@/lib/constants"

interface User {
  id: string
  name: string
  location: string
  profile_photo_url?: string
  skills: Array<{
    id: string
    name: string
    type: "Offered" | "Wanted"
    is_verified: boolean
    verification_count: number
  }>
  average_rating: number
  completed_swaps: number
}

export function UserDirectory() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const fetchUsers = async (pageNum = 1, reset = false) => {
    try {
      setLoading(true)
      const params = new URLSearchParams(searchParams.toString())
      params.set("page", pageNum.toString())
      params.set("limit", "12")

      const response = await fetch(`${BASE_URL}/api/users/public?${params.toString()}`)
      if (!response.ok) throw new Error("Failed to fetch users")

      const data = await response.json()

      if (reset) {
        setUsers(data.users || [])
      } else {
        setUsers((prev) => [...prev, ...(data.users || [])])
      }

      setHasMore(data.has_more || false)
      setPage(pageNum)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load users. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const searchTerm = searchParams.get("search") || ""
  const availability = searchParams.get("availability") || ""
  const timeslot = searchParams.get("timeslot") || ""
  const verifiedOnly = searchParams.get("verified_only") || ""

  useEffect(() => {
    fetchUsers(1, true)
  }, [searchTerm, availability, timeslot, verifiedOnly])

  const loadMore = () => {
    if (!loading && hasMore) {
      fetchUsers(page + 1, false)
    }
  }

  if (loading && users.length === 0) {
    return <LoadingSpinner />
  }

  if (users.length === 0 && !loading) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium mb-2">No users found</h3>
        <p className="text-muted-foreground">Try adjusting your search criteria or filters.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {users.map((user) => (
          <UserCard key={user.id} user={user} />
        ))}
      </div>

      {hasMore && (
        <div className="text-center">
          <Button onClick={loadMore} disabled={loading} variant="outline" size="lg">
            {loading ? "Loading..." : "Load More"}
          </Button>
        </div>
      )}
    </div>
  )
}
