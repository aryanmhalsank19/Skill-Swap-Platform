"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { apiCall } from "@/lib/api"

interface User {
  id: string
  email: string
  name: string
  profile_photo_url?: string
  location?: string
  is_public: boolean
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (data: any) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem("auth_token")
      if (!token) {
        setIsLoading(false)
        return
      }

      const userData = await apiCall("/api/users/me", { requireAuth: true })
      setUser(userData)
    } catch (error) {
      console.error("Auth check failed:", error)
      localStorage.removeItem("auth_token")
    } finally {
      setIsLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    const data = await apiCall("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    })

    localStorage.setItem("auth_token", data.access_token)
    setUser(data.user)
  }

  const register = async (userData: any) => {
    const data = await apiCall("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(userData),
    })

    localStorage.setItem("auth_token", data.access_token)
    setUser(data.user)
  }

  const logout = () => {
    localStorage.removeItem("auth_token")
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, isLoading, login, register, logout }}>{children}</AuthContext.Provider>
}
